﻿using System.Web.Mvc;

namespace PhotoProspector.Controllers
{
    public class AboutController : Controller
    {
        // GET: About
        public ActionResult Index()
        {
            return View();
        }
    }
}