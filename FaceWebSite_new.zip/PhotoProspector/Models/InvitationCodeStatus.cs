﻿namespace PhotoProspector.Models
{
    public enum InvitationCodeStatus
    {
        Matched,
        NotRegister,
        NotMatch
    }
}
