﻿'use strict';

$(function () {
    $('body').css('display', 'none');
    $('body').fadeIn();
});